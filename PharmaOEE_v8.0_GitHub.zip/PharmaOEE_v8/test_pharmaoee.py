"""
Автоматические учебные тесты для расчёта OEE.
Запуск из папки проекта: python -m unittest -v
Тесты используют только искусственные числа и не являются данными завода.
"""
import unittest
from datetime import date
from pharmaoee import calculate_oee, dates_inclusive

class OEECalculationTests(unittest.TestCase):
    def test_all_factors_100_percent(self):
        row = {
            "planned_min": 100, "run_min": 100,
            "total_count": 100, "good_count": 100,
            "ideal_cycle_sec": 60
        }
        a, p, q, oee = calculate_oee(row)
        self.assertAlmostEqual(a, 1.0)
        self.assertAlmostEqual(p, 1.0)
        self.assertAlmostEqual(q, 1.0)
        self.assertAlmostEqual(oee, 1.0)

    def test_oee_product_of_three_factors(self):
        # Условный пример: доступность 0.9, производительность 0.8, качество 0.95.
        row = {
            "planned_min": 100, "run_min": 90,
            "total_count": 72, "good_count": 68,
            "ideal_cycle_sec": 60
        }
        a, p, q, oee = calculate_oee(row)
        self.assertAlmostEqual(a, 0.9)
        self.assertAlmostEqual(p, 0.8)
        self.assertAlmostEqual(q, 68 / 72)
        self.assertAlmostEqual(oee, 0.9 * 0.8 * (68 / 72))

    def test_zero_planned_time_does_not_crash(self):
        row = {
            "planned_min": 0, "run_min": 0,
            "total_count": 0, "good_count": 0,
            "ideal_cycle_sec": 60
        }
        a, p, q, oee = calculate_oee(row)
        self.assertEqual((a, p, q, oee), (0.0, 0.0, 0.0, 0.0))

    def test_performance_is_capped_at_100_percent(self):
        # Проверяем текущее поведение прототипа: отображаемая производительность <= 100%.
        row = {
            "planned_min": 60, "run_min": 60,
            "total_count": 120, "good_count": 120,
            "ideal_cycle_sec": 60
        }
        a, p, q, oee = calculate_oee(row)
        self.assertLessEqual(p, 1.0)
        self.assertLessEqual(oee, 1.0)

class DemoDateRangeTests(unittest.TestCase):
    def test_range_includes_both_boundaries(self):
        self.assertEqual(list(dates_inclusive(date(2026, 10, 1), date(2026, 10, 3))),
                         [date(2026, 10, 1), date(2026, 10, 2), date(2026, 10, 3)])

    def test_single_day_range(self):
        self.assertEqual(list(dates_inclusive(date(2026, 10, 5), date(2026, 10, 5))),
                         [date(2026, 10, 5)])

    def test_reversed_range_is_rejected(self):
        with self.assertRaises(ValueError):
            list(dates_inclusive(date(2026, 10, 5), date(2026, 10, 1)))

if __name__ == "__main__":
    unittest.main()
