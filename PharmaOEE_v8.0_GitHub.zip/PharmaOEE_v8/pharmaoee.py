# -*- coding: utf-8 -*-
"""
PharmaOEE v8.0 — учебный настольный прототип для мониторинга OEE и учёта простоев.
Демонстрационные данные не создаются автоматически. Записи хранятся локально в SQLite.
Важно: это учебный прототип, не валидированная промышленная или GMP-система.
"""
import csv
import shutil
import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
from datetime import datetime, date, timedelta
from pathlib import Path

APP_NAME = "PharmaOEE"
DB_PATH = Path(__file__).resolve().parent / "pharmaoee.db"
REASONS = [
    "Ожидание материала", "Переналадка", "Механическая неисправность",
    "Электрическая неисправность", "Контроль качества", "Отсутствие оператора",
    "Очистка / санитарная обработка", "Прочее"
]
SHIFTS = ["1 смена", "2 смена", "3 смена"]

def connect_db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with connect_db() as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS production (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                work_date TEXT NOT NULL,
                shift TEXT NOT NULL,
                line_name TEXT NOT NULL,
                planned_min REAL NOT NULL,
                run_min REAL NOT NULL,
                total_count INTEGER NOT NULL,
                good_count INTEGER NOT NULL,
                ideal_cycle_sec REAL NOT NULL,
                note TEXT DEFAULT ''
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS downtimes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                work_date TEXT NOT NULL,
                shift TEXT NOT NULL,
                line_name TEXT NOT NULL,
                start_time TEXT NOT NULL,
                end_time TEXT NOT NULL,
                duration_min REAL NOT NULL,
                reason TEXT NOT NULL,
                comment TEXT DEFAULT ''
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS sensor_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_start TEXT NOT NULL,
                event_end TEXT DEFAULT '',
                line_name TEXT NOT NULL,
                state TEXT NOT NULL,
                source TEXT NOT NULL,
                reason TEXT DEFAULT 'Не классифицировано',
                comment TEXT DEFAULT '',
                downtime_id INTEGER DEFAULT NULL
            )
        """)

def dates_inclusive(start: date, end: date):
    """Возвращает даты от start до end включительно; обратный период запрещён."""
    if end < start:
        raise ValueError("Конечная дата не может быть раньше начальной.")
    current = start
    while current <= end:
        yield current
        current += timedelta(days=1)


def pct(v):
    return f"{v * 100:.1f}%"

def calculate_oee(row):
    planned = float(row["planned_min"] or 0)
    run = float(row["run_min"] or 0)
    total = int(row["total_count"] or 0)
    good = int(row["good_count"] or 0)
    cycle = float(row["ideal_cycle_sec"] or 0)
    availability = min(1.0, run / planned) if planned > 0 else 0.0
    performance = min(1.0, (total * cycle) / (run * 60)) if run > 0 else 0.0
    quality = min(1.0, good / total) if total > 0 else 0.0
    return availability, performance, quality, availability * performance * quality

class PharmaOEE(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("PharmaOEE v8.0 — мониторинг OEE и простоев")
        self.geometry("1180x760")
        self.minsize(980, 650)
        self.configure(bg="#f3f6fb")
        self.style = ttk.Style(self)
        try:
            self.style.theme_use("clam")
        except tk.TclError:
            pass
        self.style.configure("TFrame", background="#f3f6fb")
        self.style.configure("TLabel", background="#f3f6fb", foreground="#172b4d", font=("Segoe UI", 10))
        self.style.configure("Title.TLabel", font=("Segoe UI", 21, "bold"), foreground="#102a56")
        self.style.configure("Subtitle.TLabel", font=("Segoe UI", 10), foreground="#5b6b82")
        self.style.configure("TButton", font=("Segoe UI", 10), padding=7)
        self.style.configure("Accent.TButton", background="#1769aa", foreground="white", font=("Segoe UI", 10, "bold"))
        self.style.map("Accent.TButton", background=[("active", "#0f548d")])
        self.style.configure("Treeview", font=("Segoe UI", 10), rowheight=28, background="white", fieldbackground="white")
        self.style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"))
        self._build_header()
        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill="both", expand=True, padx=18, pady=(8, 14))
        self.dashboard_tab = ttk.Frame(self.tabs, padding=14)
        self.production_tab = ttk.Frame(self.tabs, padding=14)
        self.downtime_tab = ttk.Frame(self.tabs, padding=14)
        self.reports_tab = ttk.Frame(self.tabs, padding=14)
        self.sensor_tab = ttk.Frame(self.tabs, padding=14)
        self.tabs.add(self.dashboard_tab, text="  Обзор  ")
        self.tabs.add(self.production_tab, text="  Данные смены  ")
        self.tabs.add(self.downtime_tab, text="  Журнал простоев  ")
        self.tabs.add(self.reports_tab, text="  Отчёты и экспорт  ")
        self.tabs.add(self.sensor_tab, text="  Сбор сигналов  ")
        self.sensor_running = False
        with connect_db() as con:
            open_event = con.execute("SELECT id, state FROM sensor_events WHERE event_end='' ORDER BY id DESC LIMIT 1").fetchone()
        self.active_sensor_event_id = open_event["id"] if open_event else None
        self._build_dashboard()
        self._build_production()
        self._build_downtime()
        self._build_reports()
        self._build_sensor_tab()
        self.refresh_all()
        self.refresh_sensor_events()
        if self.active_sensor_event_id is not None:
            open_state = open_event["state"] if open_event else "STOPPED"
            if open_state == "CONNECTION_LOST":
                self.sensor_state_label.configure(text="Состояние: ПОТЕРЯ СВЯЗИ — есть незавершённое событие", bg="#fff4d6", fg="#6e4b00")
            else:
                self.sensor_state_label.configure(text="Состояние: ОСТАНОВЛЕНА — есть незавершённое событие", bg="#ffe5e5", fg="#8c2020")

    def _build_header(self):
        head = tk.Frame(self, bg="#102a56", height=82)
        head.pack(fill="x")
        head.pack_propagate(False)
        tk.Label(head, text="PharmaOEE", bg="#102a56", fg="white",
                 font=("Segoe UI", 22, "bold")).pack(side="left", padx=(22, 14), pady=16)
        tk.Label(head, text="МОНИТОРИНГ ЭФФЕКТИВНОСТИ ПРОИЗВОДСТВА",
                 bg="#102a56", fg="#c8dcf7", font=("Segoe UI", 10, "bold")).pack(side="left", pady=20)
        tk.Label(head, text="УЧЕБНЫЙ ПРОТОТИП · ЛОКАЛЬНЫЕ ДАННЫЕ",
                 bg="#102a56", fg="#ffd166", font=("Segoe UI", 9, "bold")).pack(side="right", padx=22)

    def _section_title(self, parent, title, subtitle=None):
        ttk.Label(parent, text=title, style="Title.TLabel").pack(anchor="w")
        if subtitle:
            ttk.Label(parent, text=subtitle, style="Subtitle.TLabel").pack(anchor="w", pady=(3, 12))

    def _build_dashboard(self):
        self._section_title(self.dashboard_tab, "Обзор производства",
                            "Показатели рассчитываются только по данным, сохранённым в приложении.")
        filters = ttk.Frame(self.dashboard_tab)
        filters.pack(fill="x", pady=(0, 12))
        ttk.Label(filters, text="Дата (ГГГГ-ММ-ДД):").pack(side="left")
        self.dashboard_date = tk.StringVar(value=date.today().isoformat())
        ttk.Entry(filters, textvariable=self.dashboard_date, width=14).pack(side="left", padx=8)
        ttk.Button(filters, text="Обновить", command=self.refresh_dashboard).pack(side="left")
        ttk.Button(filters, text="Демо за период…", command=self.add_demo_period).pack(side="right", padx=(8, 0))
        ttk.Button(filters, text="Демо на дату", command=self.add_demo_data).pack(side="right")
        self.kpi_frame = ttk.Frame(self.dashboard_tab)
        self.kpi_frame.pack(fill="x", pady=(0, 14))
        self.kpis = {}
        for key, label in [
            ("oee", "OEE"), ("availability", "Доступность"),
            ("performance", "Производительность"), ("quality", "Качество"),
            ("downtime", "Простои, мин"), ("units", "Выпуск, шт.")
        ]:
            card = tk.Frame(self.kpi_frame, bg="white", highlightbackground="#d8e1ef", highlightthickness=1)
            card.pack(side="left", fill="both", expand=True, padx=4, ipady=12)
            tk.Label(card, text=label, bg="white", fg="#62738b", font=("Segoe UI", 9, "bold")).pack(pady=(8, 5))
            value = tk.Label(card, text="—", bg="white", fg="#1769aa", font=("Segoe UI", 19, "bold"))
            value.pack(pady=(0, 8))
            self.kpis[key] = value
        ttk.Label(self.dashboard_tab, text="Последние записи смен", font=("Segoe UI", 12, "bold")).pack(anchor="w", pady=(6, 7))
        cols = ("date", "shift", "line", "run", "units", "oee")
        self.dashboard_tree = ttk.Treeview(self.dashboard_tab, columns=cols, show="headings", height=9)
        headers = {"date":"Дата", "shift":"Смена", "line":"Линия", "run":"Работа, мин", "units":"Выпуск, шт.", "oee":"OEE"}
        widths = {"date":110, "shift":100, "line":210, "run":130, "units":130, "oee":100}
        for c in cols:
            self.dashboard_tree.heading(c, text=headers[c])
            self.dashboard_tree.column(c, width=widths[c], anchor="center")
        self.dashboard_tree.pack(fill="both", expand=True)

    def _build_production(self):
        self._section_title(self.production_tab, "Данные производственной смены",
                            "Вводите значения из подтверждённых журналов или измерений. Не вводите предположения как факты.")
        form = ttk.Frame(self.production_tab)
        form.pack(anchor="nw", fill="x")
        self.prod_vars = {
            "date": tk.StringVar(value=date.today().isoformat()),
            "shift": tk.StringVar(value=SHIFTS[0]),
            "line": tk.StringVar(value="Линия фасовки 1"),
            "planned": tk.StringVar(value="480"),
            "run": tk.StringVar(value=""),
            "total": tk.StringVar(value=""),
            "good": tk.StringVar(value=""),
            "cycle": tk.StringVar(value=""),
            "note": tk.StringVar(value="")
        }
        fields = [
            ("Дата (ГГГГ-ММ-ДД)", "date", 18), ("Смена", "shift", 18),
            ("Линия / оборудование", "line", 28), ("Плановое время, мин", "planned", 18),
            ("Время работы, мин", "run", 18), ("Всего произведено, шт.", "total", 18),
            ("Годных единиц, шт.", "good", 18), ("Идеальный цикл, сек/шт.", "cycle", 18),
            ("Комментарий", "note", 50)
        ]
        for i, (label, key, width) in enumerate(fields):
            r, c = divmod(i, 3)
            cell = ttk.Frame(form)
            cell.grid(row=r, column=c, sticky="ew", padx=(0, 18), pady=8)
            ttk.Label(cell, text=label).pack(anchor="w", pady=(0, 4))
            if key == "shift":
                ttk.Combobox(cell, textvariable=self.prod_vars[key], values=SHIFTS, state="readonly", width=width).pack(fill="x")
            else:
                ttk.Entry(cell, textvariable=self.prod_vars[key], width=width).pack(fill="x")
            form.columnconfigure(c, weight=1)
        ttk.Button(self.production_tab, text="Сохранить данные смены", style="Accent.TButton",
                   command=self.save_production).pack(anchor="w", pady=(16, 10))
        ttk.Label(self.production_tab, text="Формула: OEE = Доступность × Производительность × Качество. "
                   "Производительность ограничивается 100% в отображаемом расчёте; исходные значения сохраняются.",
                   wraplength=950).pack(anchor="w", pady=5)
        ttk.Label(self.production_tab, text="Плановое время должно быть больше нуля; время работы не может превышать плановое. "
                   "Идеальный цикл — нормативное время выпуска одной единицы в секундах.",
                   wraplength=950, style="Subtitle.TLabel").pack(anchor="w", pady=5)

    def _build_downtime(self):
        self._section_title(self.downtime_tab, "Журнал простоев",
                            "Для простоты прототип принимает дату, время начала и окончания. Пересечение полуночи не поддерживается.")
        form = ttk.Frame(self.downtime_tab)
        form.pack(fill="x", pady=(0, 14))
        self.down_vars = {
            "date": tk.StringVar(value=date.today().isoformat()),
            "shift": tk.StringVar(value=SHIFTS[0]),
            "line": tk.StringVar(value="Линия фасовки 1"),
            "start": tk.StringVar(value="10:00"),
            "end": tk.StringVar(value="10:15"),
            "reason": tk.StringVar(value=REASONS[0]),
            "comment": tk.StringVar(value="")
        }
        fields = [
            ("Дата (ГГГГ-ММ-ДД)", "date"), ("Смена", "shift"), ("Линия / оборудование", "line"),
            ("Начало (ЧЧ:ММ)", "start"), ("Окончание (ЧЧ:ММ)", "end"), ("Причина", "reason"),
            ("Комментарий", "comment")
        ]
        for i, (label, key) in enumerate(fields):
            r, c = divmod(i, 3)
            cell = ttk.Frame(form)
            cell.grid(row=r, column=c, sticky="ew", padx=(0, 18), pady=7)
            ttk.Label(cell, text=label).pack(anchor="w", pady=(0, 4))
            if key == "shift":
                ttk.Combobox(cell, textvariable=self.down_vars[key], values=SHIFTS, state="readonly", width=20).pack(fill="x")
            elif key == "reason":
                ttk.Combobox(cell, textvariable=self.down_vars[key], values=REASONS, state="readonly", width=30).pack(fill="x")
            else:
                ttk.Entry(cell, textvariable=self.down_vars[key], width=32).pack(fill="x")
            form.columnconfigure(c, weight=1)
        ttk.Button(self.downtime_tab, text="Добавить простой", style="Accent.TButton",
                   command=self.save_downtime).pack(anchor="w", pady=(0, 14))
        filterbar = ttk.Frame(self.downtime_tab)
        filterbar.pack(fill="x", pady=(0, 10))
        ttk.Label(filterbar, text="Фильтр по дате (ГГГГ-ММ-ДД, пусто — все даты):").pack(side="left")
        self.down_filter_date = tk.StringVar(value="")
        ttk.Entry(filterbar, textvariable=self.down_filter_date, width=14).pack(side="left", padx=8)
        ttk.Button(filterbar, text="Применить фильтр", command=self.refresh_downtimes).pack(side="left")
        ttk.Button(filterbar, text="Сбросить", command=self.clear_downtime_filter).pack(side="left", padx=6)
        ttk.Label(self.downtime_tab, text="Записи журнала", font=("Segoe UI", 12, "bold")).pack(anchor="w", pady=(0, 6))
        cols = ("id", "date", "shift", "line", "start", "end", "duration", "reason", "comment")
        self.down_tree = ttk.Treeview(self.downtime_tab, columns=cols, show="headings", height=12)
        names = {"id":"ID", "date":"Дата", "shift":"Смена", "line":"Линия", "start":"Начало",
                 "end":"Окончание", "duration":"Мин.", "reason":"Причина", "comment":"Комментарий"}
        widths = {"id":45, "date":100, "shift":85, "line":155, "start":75, "end":85, "duration":65, "reason":190, "comment":180}
        for c in cols:
            self.down_tree.heading(c, text=names[c])
            self.down_tree.column(c, width=widths[c], anchor="center" if c != "comment" else "w")
        self.down_tree.pack(fill="both", expand=True)

    def _build_reports(self):
        self._section_title(self.reports_tab, "Отчёты и аналитика",
                            "Сводка строится только по сохранённым записям. Период, смена и линия — необязательные фильтры.")
        filters = ttk.Frame(self.reports_tab)
        filters.pack(fill="x", pady=(0, 10))
        self.report_from = tk.StringVar(value="")
        self.report_to = tk.StringVar(value="")
        self.report_shift = tk.StringVar(value="Все смены")
        self.report_line = tk.StringVar(value="")
        fields = [
            ("С даты (ГГГГ-ММ-ДД)", self.report_from, 17),
            ("По дату включительно", self.report_to, 17),
            ("Смена", self.report_shift, 17),
            ("Линия (точное имя)", self.report_line, 24),
        ]
        for i, (label, var, width) in enumerate(fields):
            cell = ttk.Frame(filters)
            cell.grid(row=0, column=i, padx=(0, 10), sticky="ew")
            ttk.Label(cell, text=label).pack(anchor="w", pady=(0, 4))
            if var is self.report_shift:
                ttk.Combobox(cell, textvariable=var, values=["Все смены"] + SHIFTS,
                             state="readonly", width=width).pack(fill="x")
            else:
                ttk.Entry(cell, textvariable=var, width=width).pack(fill="x")
            filters.columnconfigure(i, weight=1)
        actions = ttk.Frame(self.reports_tab)
        actions.pack(fill="x", pady=(0, 6))
        ttk.Button(actions, text="Построить сводку", style="Accent.TButton", command=self.show_reason_summary).pack(side="left", padx=(0, 8))
        ttk.Button(actions, text="Сбросить фильтры", command=self.clear_report_filters).pack(side="left", padx=(0, 18))
        ttk.Button(actions, text="Экспорт смен (CSV)", command=lambda: self.export_csv("production")).pack(side="left", padx=(0, 8))
        ttk.Button(actions, text="Экспорт простоев (CSV)", command=lambda: self.export_csv("downtimes")).pack(side="left", padx=(0, 8))
        ttk.Button(actions, text="Резервная копия базы…", command=self.backup_database).pack(side="left")
        self.report_text = tk.Text(self.reports_tab, height=18, wrap="word", font=("Consolas", 10),
                                   bg="white", fg="#172b4d", relief="solid", bd=1)
        self.report_text.pack(fill="both", expand=True, pady=(10, 0))
        self.report_text.insert("1.0", "Укажи фильтры при необходимости и нажми «Построить сводку».\n")


    def _build_sensor_tab(self):
        self._section_title(self.sensor_tab, "Сбор сигналов оборудования",
            "ДЕМО-РЕЖИМ: кнопки имитируют сигнал датчика. Реальное оборудование пока не подключено.")
        info = tk.Frame(self.sensor_tab, bg="#fff4d6", highlightbackground="#e8ca7a", highlightthickness=1)
        info.pack(fill="x", pady=(0, 12))
        tk.Label(info, text="Важно: текущий источник — симулятор, а не физический датчик или PLC.",
                 bg="#fff4d6", fg="#6e4b00", font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=12, pady=9)
        form = ttk.Frame(self.sensor_tab)
        form.pack(fill="x", pady=(0, 12))
        self.sensor_line = tk.StringVar(value="Линия фасовки 1")
        self.sensor_source = tk.StringVar(value="Симулятор сигнала")
        ttk.Label(form, text="Линия / оборудование:").grid(row=0, column=0, sticky="w", padx=(0,8), pady=6)
        ttk.Entry(form, textvariable=self.sensor_line, width=32).grid(row=0, column=1, sticky="w", pady=6)
        ttk.Label(form, text="Источник:").grid(row=1, column=0, sticky="w", padx=(0,8), pady=6)
        ttk.Label(form, textvariable=self.sensor_source).grid(row=1, column=1, sticky="w", pady=6)
        self.sensor_state_label = tk.Label(self.sensor_tab, text="Состояние: НЕИЗВЕСТНО", bg="#e9edf3", fg="#26374a",
                                           font=("Segoe UI", 15, "bold"), padx=16, pady=14)
        self.sensor_state_label.pack(fill="x", pady=(0, 12))
        buttons = ttk.Frame(self.sensor_tab)
        buttons.pack(fill="x", pady=(0, 12))
        ttk.Button(buttons, text="Сигнал: линия РАБОТАЕТ", style="Accent.TButton",
                   command=lambda: self.set_sensor_state("RUNNING")).pack(side="left", padx=(0,8))
        ttk.Button(buttons, text="Сигнал: линия ОСТАНОВЛЕНА",
                   command=lambda: self.set_sensor_state("STOPPED")).pack(side="left", padx=(0,8))
        ttk.Button(buttons, text="Сигнал: ПОТЕРЯ СВЯЗИ",
                   command=lambda: self.set_sensor_state("CONNECTION_LOST")).pack(side="left", padx=(0,8))
        ttk.Button(buttons, text="Обновить события", command=self.refresh_sensor_events).pack(side="left")
        ttk.Label(self.sensor_tab, text="События датчика и ручная классификация", font=("Segoe UI", 12, "bold")).pack(anchor="w", pady=(4,6))
        cols = ("id", "start", "end", "line", "state", "source", "reason", "comment")
        self.sensor_tree = ttk.Treeview(self.sensor_tab, columns=cols, show="headings", height=9)
        headers = {"id":"ID", "start":"Начало", "end":"Окончание", "line":"Линия", "state":"Состояние",
                   "source":"Источник", "reason":"Причина", "comment":"Комментарий"}
        widths = {"id":45, "start":155, "end":155, "line":145, "state":95, "source":130, "reason":170, "comment":180}
        for c in cols:
            self.sensor_tree.heading(c, text=headers[c])
            self.sensor_tree.column(c, width=widths[c], anchor="center" if c != "comment" else "w")
        self.sensor_tree.pack(fill="both", expand=True)
        classify = ttk.Frame(self.sensor_tab)
        classify.pack(fill="x", pady=(10,0))
        self.sensor_reason = tk.StringVar(value=REASONS[0])
        self.sensor_comment = tk.StringVar(value="")
        ttk.Label(classify, text="Причина для выбранного события:").grid(row=0, column=0, sticky="w", padx=(0,8), pady=5)
        ttk.Combobox(classify, textvariable=self.sensor_reason, values=REASONS + ["Не классифицировано"],
                     state="readonly", width=28).grid(row=0, column=1, sticky="w", pady=5)
        ttk.Label(classify, text="Комментарий оператора:").grid(row=1, column=0, sticky="w", padx=(0,8), pady=5)
        ttk.Entry(classify, textvariable=self.sensor_comment, width=48).grid(row=1, column=1, sticky="ew", pady=5)
        ttk.Button(classify, text="Сохранить классификацию", command=self.classify_sensor_event).grid(row=0, column=2, rowspan=2, padx=12)
        classify.columnconfigure(1, weight=1)

    def set_sensor_state(self, state):
        line = self.sensor_line.get().strip()
        if not line:
            messagebox.showerror("Линия не указана", "Укажи название линии или оборудования.")
            return
        now = datetime.now()
        stamp = now.strftime("%Y-%m-%d %H:%M:%S")
        if state in ("STOPPED", "CONNECTION_LOST"):
            if self.active_sensor_event_id is not None:
                self.sensor_state_label.configure(text="Состояние: уже есть незавершённое событие; сначала верни линию в работу", bg="#fff4d6", fg="#6e4b00")
                return
            if state == "CONNECTION_LOST":
                reason = "Потеря связи"
                comment = "Демонстрационное событие: связь с источником данных недоступна; состояние оборудования требует проверки"
                label = "ПОТЕРЯ СВЯЗИ"
                bg, fg = "#fff4d6", "#6e4b00"
            else:
                reason = "Не классифицировано"
                comment = "Демонстрационный сигнал STOPPED; причина остановки не определяется симулятором"
                label = "ОСТАНОВЛЕНА"
                bg, fg = "#ffe5e5", "#8c2020"
            with connect_db() as con:
                cur = con.execute("INSERT INTO sensor_events (event_start,line_name,state,source,reason,comment) VALUES (?,?,?,?,?,?)",
                                  (stamp,line,state,"Симулятор сигнала",reason,comment))
                self.active_sensor_event_id = cur.lastrowid
            self.sensor_state_label.configure(text=f"Состояние: {label} с {now.strftime('%H:%M:%S')} — событие зафиксировано", bg=bg, fg=fg)
        else:
            if self.active_sensor_event_id is not None:
                with connect_db() as con:
                    event = con.execute("SELECT * FROM sensor_events WHERE id=?", (self.active_sensor_event_id,)).fetchone()
                    if event:
                        start_dt = datetime.strptime(event["event_start"], "%Y-%m-%d %H:%M:%S")
                        duration = max(0.0, (now - start_dt).total_seconds() / 60)
                        # Для журнала простоя используем минутную точность интерфейса; исходные секунды остаются в sensor_events.
                        con.execute("UPDATE sensor_events SET event_end=?, state='RUNNING' WHERE id=?", (stamp, self.active_sensor_event_id))
                        cur = con.execute("INSERT INTO downtimes (work_date,shift,line_name,start_time,end_time,duration_min,reason,comment) VALUES (?,?,?,?,?,?,?,?)",
                            (start_dt.date().isoformat(), SHIFTS[0], event["line_name"], start_dt.strftime("%H:%M"), now.strftime("%H:%M"), duration,
                             event["reason"], "Источник: симулятор сигнала. " + (event["comment"] or "")))
                        con.execute("UPDATE sensor_events SET downtime_id=? WHERE id=?", (cur.lastrowid, self.active_sensor_event_id))
                self.active_sensor_event_id = None
                self.refresh_all()
            self.sensor_state_label.configure(text=f"Состояние: РАБОТАЕТ с {now.strftime('%H:%M:%S')}", bg="#e2f5e9", fg="#17633a")
        self.refresh_sensor_events()

    def refresh_sensor_events(self):
        if not hasattr(self, "sensor_tree"):
            return
        for item in self.sensor_tree.get_children():
            self.sensor_tree.delete(item)
        with connect_db() as con:
            rows = con.execute("SELECT * FROM sensor_events ORDER BY id DESC LIMIT 200").fetchall()
        for r in rows:
            state_label = {"RUNNING": "РАБОТАЕТ", "STOPPED": "ОСТАНОВКА", "CONNECTION_LOST": "ПОТЕРЯ СВЯЗИ"}.get(r["state"], r["state"])
            self.sensor_tree.insert("", "end", values=(r["id"], r["event_start"], r["event_end"] or "В процессе",
                r["line_name"], state_label, r["source"], r["reason"], r["comment"]))

    def classify_sensor_event(self):
        selected = self.sensor_tree.selection()
        if not selected:
            messagebox.showwarning("Выбери событие", "Выбери строку события в таблице.")
            return
        event_id = int(self.sensor_tree.item(selected[0], "values")[0])
        reason = self.sensor_reason.get().strip()
        comment = self.sensor_comment.get().strip()
        with connect_db() as con:
            row = con.execute("SELECT * FROM sensor_events WHERE id=?", (event_id,)).fetchone()
            if not row:
                messagebox.showerror("Событие не найдено", "Обнови список и попробуй снова.")
                return
            con.execute("UPDATE sensor_events SET reason=?, comment=? WHERE id=?", (reason, comment, event_id))
            if row["downtime_id"]:
                con.execute("UPDATE downtimes SET reason=?, comment=? WHERE id=?", (reason, comment, row["downtime_id"]))
        messagebox.showinfo("Сохранено", "Причина и комментарий сохранены. Если событие уже завершено, обнови журнал простоев.")
        self.refresh_sensor_events()
        self.refresh_all()

    def _valid_date(self, value):
        datetime.strptime(value, "%Y-%m-%d")

    def save_production(self):
        v = {k: x.get().strip() for k, x in self.prod_vars.items()}
        try:
            self._valid_date(v["date"])
            planned, run = float(v["planned"]), float(v["run"])
            total, good, cycle = int(v["total"]), int(v["good"]), float(v["cycle"])
            if not v["line"]: raise ValueError("Укажите линию или оборудование.")
            if planned <= 0 or run < 0 or run > planned: raise ValueError("Время работы должно быть от 0 до планового времени.")
            if total < 0 or good < 0 or good > total: raise ValueError("Количество годных единиц должно быть от 0 до общего выпуска.")
            if cycle <= 0: raise ValueError("Идеальный цикл должен быть больше нуля.")
            if not v["total"] or not v["good"] or not v["run"] or not v["cycle"]:
                raise ValueError("Заполните время работы, выпуск, годный выпуск и идеальный цикл.")
            with connect_db() as con:
                con.execute("""INSERT INTO production
                    (work_date,shift,line_name,planned_min,run_min,total_count,good_count,ideal_cycle_sec,note)
                    VALUES (?,?,?,?,?,?,?,?,?)""",
                    (v["date"],v["shift"],v["line"],planned,run,total,good,cycle,v["note"]))
            messagebox.showinfo("Сохранено", "Данные смены сохранены в локальную базу.")
            self.refresh_all()
        except ValueError as e:
            messagebox.showerror("Проверьте данные", str(e) or "Некорректный формат даты или числа.")
        except sqlite3.Error as e:
            messagebox.showerror("Ошибка базы данных", str(e))

    def save_downtime(self):
        v = {k: x.get().strip() for k, x in self.down_vars.items()}
        try:
            self._valid_date(v["date"])
            start = datetime.strptime(v["start"], "%H:%M")
            end = datetime.strptime(v["end"], "%H:%M")
            duration = (end - start).total_seconds() / 60
            if duration <= 0: raise ValueError("Время окончания должно быть позже времени начала в пределах одних суток.")
            if not v["line"]: raise ValueError("Укажите линию или оборудование.")
            with connect_db() as con:
                con.execute("""INSERT INTO downtimes
                    (work_date,shift,line_name,start_time,end_time,duration_min,reason,comment)
                    VALUES (?,?,?,?,?,?,?,?)""",
                    (v["date"],v["shift"],v["line"],v["start"],v["end"],duration,v["reason"],v["comment"]))
            messagebox.showinfo("Сохранено", f"Простой {duration:.0f} мин добавлен в журнал.")
            self.refresh_all()
        except ValueError as e:
            messagebox.showerror("Проверьте данные", str(e) or "Некорректная дата или время.")
        except sqlite3.Error as e:
            messagebox.showerror("Ошибка базы данных", str(e))

    def refresh_all(self):
        self.refresh_dashboard()
        self.refresh_downtimes()

    def refresh_dashboard(self):
        day = self.dashboard_date.get().strip()
        try:
            self._valid_date(day)
        except ValueError:
            messagebox.showerror("Дата", "Введите дату в формате ГГГГ-ММ-ДД.")
            return
        with connect_db() as con:
            rows = con.execute("SELECT * FROM production WHERE work_date=? ORDER BY id DESC", (day,)).fetchall()
            down = con.execute("SELECT COALESCE(SUM(duration_min),0) AS mins FROM downtimes WHERE work_date=?", (day,)).fetchone()["mins"]
        if rows:
            planned = sum(r["planned_min"] for r in rows)
            run = sum(r["run_min"] for r in rows)
            total = sum(r["total_count"] for r in rows)
            good = sum(r["good_count"] for r in rows)
            ideal_seconds = sum(r["total_count"] * r["ideal_cycle_sec"] for r in rows)
            av = min(1, run / planned) if planned else 0
            perf = min(1, ideal_seconds / (run * 60)) if run else 0
            quality = good / total if total else 0
            oee = av * perf * quality
            values = {"oee":pct(oee), "availability":pct(av), "performance":pct(perf),
                      "quality":pct(quality), "downtime":f"{down:.0f}", "units":f"{total:,}".replace(",", " ")}
        else:
            values = {"oee":"—", "availability":"—", "performance":"—", "quality":"—",
                      "downtime":f"{down:.0f}", "units":"—"}
        for key, value in values.items():
            self.kpis[key].configure(text=value)
        for item in self.dashboard_tree.get_children():
            self.dashboard_tree.delete(item)
        for r in rows:
            av, perf, quality, oee = calculate_oee(r)
            self.dashboard_tree.insert("", "end", values=(r["work_date"], r["shift"], r["line_name"],
                f'{r["run_min"]:.0f}', r["total_count"], pct(oee)))

    def clear_downtime_filter(self):
        self.down_filter_date.set("")
        self.refresh_downtimes()

    def refresh_downtimes(self):
        for item in self.down_tree.get_children():
            self.down_tree.delete(item)
        filter_date = self.down_filter_date.get().strip()
        try:
            if filter_date:
                self._valid_date(filter_date)
        except ValueError:
            messagebox.showerror("Дата фильтра", "Введите дату в формате ГГГГ-ММ-ДД или оставьте поле пустым.")
            return
        with connect_db() as con:
            if filter_date:
                rows = con.execute("SELECT * FROM downtimes WHERE work_date=? ORDER BY work_date DESC, id DESC LIMIT 500", (filter_date,)).fetchall()
            else:
                rows = con.execute("SELECT * FROM downtimes ORDER BY work_date DESC, id DESC LIMIT 500").fetchall()
        for r in rows:
            self.down_tree.insert("", "end", values=(r["id"],r["work_date"],r["shift"],r["line_name"],
                r["start_time"],r["end_time"],f'{r["duration_min"]:.0f}',r["reason"],r["comment"]))

    def add_demo_data(self):
        # Демонстрационные записи должны создаваться на дату, выбранную пользователем,
        # а не всегда на сегодняшнюю дату.
        selected_day = self.dashboard_date.get().strip()
        try:
            self._valid_date(selected_day)
        except ValueError:
            messagebox.showerror("Дата", "Введите дату на вкладке «Обзор производства» в формате ГГГГ-ММ-ДД.")
            return

        if not messagebox.askyesno(
                "Демонстрационные данные",
                f"Добавить условную демонстрационную смену и простои на дату {selected_day}?\n\n"
                "Это ИСКУССТВЕННЫЕ данные для проверки приложения, не результаты завода."):
            return

        demo_line = "ДЕМО — линия фасовки"
        with connect_db() as con:
            # Защита от случайного повторного добавления одной и той же демо-смены.
            exists = con.execute(
                "SELECT 1 FROM production WHERE work_date=? AND shift=? AND line_name=? AND note=? LIMIT 1",
                (selected_day, "1 смена", demo_line, "ИСКУССТВЕННЫЕ ДАННЫЕ ДЛЯ ДЕМОНСТРАЦИИ")
            ).fetchone()
            if exists:
                messagebox.showinfo(
                    "Демо-данные уже есть",
                    f"На дату {selected_day} демонстрационная смена уже добавлена.\n"
                    "Чтобы избежать дублей, повторная запись не создана.")
                self.refresh_all()
                return

            con.execute("""INSERT INTO production
                (work_date,shift,line_name,planned_min,run_min,total_count,good_count,ideal_cycle_sec,note)
                VALUES (?,?,?,?,?,?,?,?,?)""",
                (selected_day, "1 смена", demo_line, 480, 420, 18000, 17640, 1.2,
                 "ИСКУССТВЕННЫЕ ДАННЫЕ ДЛЯ ДЕМОНСТРАЦИИ"))
            con.execute("""INSERT INTO downtimes
                (work_date,shift,line_name,start_time,end_time,duration_min,reason,comment)
                VALUES (?,?,?,?,?,?,?,?)""",
                (selected_day, "1 смена", demo_line, "09:10", "09:25", 15,
                 "Ожидание материала", "Демо-запись, не факт производства"))
            con.execute("""INSERT INTO downtimes
                (work_date,shift,line_name,start_time,end_time,duration_min,reason,comment)
                VALUES (?,?,?,?,?,?,?,?)""",
                (selected_day, "1 смена", demo_line, "11:40", "12:00", 20,
                 "Переналадка", "Демо-запись, не факт производства"))

        # Применяем фильтр выбранной даты и в журнале простоев, чтобы пользователь
        # сразу видел добавленные записи за тот же день.
        self.down_filter_date.set(selected_day)
        self.refresh_all()
        messagebox.showinfo(
            "Добавлено",
            f"Демонстрационные записи добавлены на {selected_day}.\n"
            "Они помечены как условные и не являются данными реального производства.")

    def add_demo_period(self):
        """Создаёт условные демо-записи на каждый день выбранного периода включительно."""
        start_text = simpledialog.askstring(
            "Демо-данные за период", "Начальная дата (ГГГГ-ММ-ДД):",
            initialvalue=self.dashboard_date.get().strip(), parent=self)
        if start_text is None:
            return
        end_text = simpledialog.askstring(
            "Демо-данные за период", "Конечная дата включительно (ГГГГ-ММ-ДД):",
            initialvalue=start_text.strip(), parent=self)
        if end_text is None:
            return
        start_text, end_text = start_text.strip(), end_text.strip()
        try:
            start = date.fromisoformat(start_text)
            end = date.fromisoformat(end_text)
            if start.isoformat() != start_text or end.isoformat() != end_text:
                raise ValueError
            if end < start:
                raise ValueError("Конечная дата не может быть раньше начальной.")
            if (end - start).days > 365:
                raise ValueError("Для защиты от случайного заполнения выберите период не больше 366 дней.")
        except ValueError as e:
            messagebox.showerror("Проверьте даты", str(e) or "Введите даты в формате ГГГГ-ММ-ДД.")
            return

        days = (end - start).days + 1
        if not messagebox.askyesno(
            "Подтверждение", f"Создать демонстрационные смены за {days} дн. — с {start} по {end}?\n\n"
            "Данные искусственные и не являются результатами реального производства.\n"
            "Дни, для которых демо-смена уже существует, будут пропущены.", parent=self):
            return

        inserted = 0
        skipped = 0
        demo_line = "ДЕМО — линия фасовки"
        with connect_db() as con:
            for current in dates_inclusive(start, end):
                day = current.isoformat()
                exists = con.execute(
                    "SELECT 1 FROM production WHERE work_date=? AND shift=? AND line_name=? AND note=? LIMIT 1",
                    (day, "1 смена", demo_line, "ИСКУССТВЕННЫЕ ДАННЫЕ ДЛЯ ДЕМОНСТРАЦИИ")
                ).fetchone()
                if exists:
                    skipped += 1
                else:
                    con.execute("""INSERT INTO production
                        (work_date,shift,line_name,planned_min,run_min,total_count,good_count,ideal_cycle_sec,note)
                        VALUES (?,?,?,?,?,?,?,?,?)""",
                        (day, "1 смена", demo_line, 480, 420, 18000, 17640, 1.2,
                         "ИСКУССТВЕННЫЕ ДАННЫЕ ДЛЯ ДЕМОНСТРАЦИИ"))
                    con.execute("""INSERT INTO downtimes
                        (work_date,shift,line_name,start_time,end_time,duration_min,reason,comment)
                        VALUES (?,?,?,?,?,?,?,?)""",
                        (day, "1 смена", demo_line, "09:10", "09:25", 15,
                         "Ожидание материала", "Демо-запись, не факт производства"))
                    con.execute("""INSERT INTO downtimes
                        (work_date,shift,line_name,start_time,end_time,duration_min,reason,comment)
                        VALUES (?,?,?,?,?,?,?,?)""",
                        (day, "1 смена", demo_line, "11:40", "12:00", 20,
                         "Переналадка", "Демо-запись, не факт производства"))
                    inserted += 1

        self.dashboard_date.set(start.isoformat())
        self.down_filter_date.set(start.isoformat())
        self.refresh_all()
        messagebox.showinfo(
            "Демо-данные обработаны",
            f"Добавлено смен: {inserted}.\nПропущено дней (демо уже было): {skipped}.\n"
            f"Период: {start} — {end}.\n\nВсе созданные записи помечены как искусственные.", parent=self)

    def backup_database(self):
        """Создаёт согласованную копию SQLite через встроенный backup API."""
        target = filedialog.asksaveasfilename(
            title="Сохранить резервную копию базы", defaultextension=".db",
            initialfile=f"pharmaoee_backup_{date.today().isoformat()}.db",
            filetypes=[("SQLite database", "*.db")])
        if not target:
            return
        try:
            destination = sqlite3.connect(target)
            try:
                with connect_db() as source:
                    source.backup(destination)
            finally:
                destination.close()
            messagebox.showinfo("Резервная копия создана", f"Копия базы сохранена:\n{target}", parent=self)
        except (OSError, sqlite3.Error) as e:
            messagebox.showerror("Ошибка резервного копирования", str(e), parent=self)

    def export_csv(self, table):
        if table == "production":
            query = "SELECT * FROM production ORDER BY work_date DESC, id DESC"
            default = "pharmaoee_production.csv"
        else:
            query = "SELECT * FROM downtimes ORDER BY work_date DESC, id DESC"
            default = "pharmaoee_downtimes.csv"
        path = filedialog.asksaveasfilename(title="Сохранить CSV", defaultextension=".csv",
                                             initialfile=default, filetypes=[("CSV", "*.csv")])
        if not path: return
        with connect_db() as con:
            rows = con.execute(query).fetchall()
        try:
            with open(path, "w", newline="", encoding="utf-8-sig") as f:
                writer = csv.writer(f, delimiter=";")
                if rows:
                    writer.writerow(rows[0].keys())
                    for row in rows: writer.writerow([row[k] for k in row.keys()])
                else:
                    writer.writerow(["Нет сохранённых записей"])
            messagebox.showinfo("Экспорт завершён", f"Записей: {len(rows)}\nФайл: {path}")
        except OSError as e:
            messagebox.showerror("Ошибка экспорта", str(e))

    def clear_report_filters(self):
        self.report_from.set("")
        self.report_to.set("")
        self.report_shift.set("Все смены")
        self.report_line.set("")
        self.show_reason_summary()

    def show_reason_summary(self):
        start_date = self.report_from.get().strip()
        end_date = self.report_to.get().strip()
        shift = self.report_shift.get().strip()
        line = self.report_line.get().strip()
        try:
            if start_date:
                self._valid_date(start_date)
            if end_date:
                self._valid_date(end_date)
            if start_date and end_date and start_date > end_date:
                raise ValueError("Начальная дата не может быть позже конечной.")
        except ValueError as e:
            messagebox.showerror("Проверьте фильтры", str(e) or "Введите дату в формате ГГГГ-ММ-ДД.")
            return

        where = []
        params = []
        if start_date:
            where.append("work_date >= ?")
            params.append(start_date)
        if end_date:
            where.append("work_date <= ?")
            params.append(end_date)
        if shift and shift != "Все смены":
            where.append("shift = ?")
            params.append(shift)
        if line:
            where.append("line_name = ?")
            params.append(line)
        clause = (" WHERE " + " AND ".join(where)) if where else ""
        with connect_db() as con:
            rows = con.execute("SELECT reason, COUNT(*) AS cnt, SUM(duration_min) AS mins FROM downtimes" +
                               clause + " GROUP BY reason ORDER BY mins DESC", params).fetchall()
            total = con.execute("SELECT COALESCE(SUM(duration_min),0) AS mins, COUNT(*) AS cnt FROM downtimes" +
                                clause, params).fetchone()
        self.report_text.delete("1.0", "end")
        self.report_text.insert("end", "СВОДКА ПО ПРИЧИНАМ ПРОСТОЕВ\n")
        self.report_text.insert("end", "=" * 64 + "\n")
        period = f"с {start_date or 'начала истории'} по {end_date or 'последнюю дату'}"
        self.report_text.insert("end", f"Период: {period} | Смена: {shift or 'Все смены'} | Линия: {line or 'Все линии'}\n")
        self.report_text.insert("end", f"Записей простоев: {total['cnt']} | Суммарно: {total['mins']:.0f} мин\n\n")
        if not rows:
            self.report_text.insert("end", "По выбранным фильтрам записей нет. Попробуй изменить фильтры или добавить тестовую запись.\n")
        else:
            for r in rows:
                share = (r["mins"] / total["mins"] * 100) if total["mins"] else 0
                bar = "#" * max(1, round(share / 5)) if r["mins"] else ""
                self.report_text.insert("end", f"{r['reason']:<34} {r['mins']:>7.0f} мин  {share:>5.1f}%  ({r['cnt']} записей)  {bar}\n")
        self.report_text.insert("end", "\nПримечание: сводка отражает только введённые записи; она не доказывает снижение простоев.\n")

if __name__ == "__main__":
    init_db()
    app = PharmaOEE()
    app.mainloop()
