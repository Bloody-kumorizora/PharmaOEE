﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py pharmaoee.py
) else (
  python pharmaoee.py
)
if errorlevel 1 (
  echo.
  echo Не удалось запустить PharmaOEE. Проверьте установку Python и поддержку Tkinter.
  pause
)
